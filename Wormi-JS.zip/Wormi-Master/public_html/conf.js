const conf = {
    rate_of_change: 10
}
